// SCORM 1.2 API Wrapper
var SCORM = {
    API: null,
    isInitialized: false,

    // Find the SCORM API
    findAPI: function(win) {
        var findAttempts = 0;
        var findAttemptLimit = 500;

        while ((win.API == null) && (win.parent != null) && (win.parent != win)) {
            findAttempts++;
            if (findAttempts > findAttemptLimit) {
                console.log("Error finding API -- too deeply nested.");
                return null;
            }
            win = win.parent;
        }
        return win.API;
    },

    // Get the API
    getAPI: function() {
        if (this.API == null) {
            this.API = this.findAPI(window);
        }
        return this.API;
    },

    // Initialize the SCORM communication
    initialize: function() {
        var api = this.getAPI();
        if (api == null) {
            console.log("Unable to locate the LMS's API Implementation. LMSInitialize was not successful.");
            return false;
        }

        var result = api.LMSInitialize("");

        if (result.toString() != "true") {
            var err = this.getLastError();
            console.log("LMSInitialize failed with error code: " + err);
            return false;
        }

        this.isInitialized = true;
        console.log("SCORM initialized successfully");
        return true;
    },

    // Terminate the SCORM communication
    terminate: function() {
        var api = this.getAPI();
        if (api == null) {
            console.log("Unable to locate the LMS's API Implementation. LMSFinish was not successful.");
            return false;
        }

        // Don't terminate if we haven't initialized
        if (!this.isInitialized) {
            console.log("SCORM not initialized, skipping terminate");
            return true;
        }

        var result = api.LMSFinish("");

        if (result.toString() != "true") {
            var err = this.getLastError();
            console.log("LMSFinish failed with error code: " + err);
            return false;
        }

        this.isInitialized = false;
        console.log("SCORM terminated successfully");
        return true;
    },

    // Get a value from the LMS
    getValue: function(element) {
        var api = this.getAPI();
        if (api == null) {
            console.log("Unable to locate the LMS's API Implementation. LMSGetValue was not successful.");
            return "";
        }

        var value = api.LMSGetValue(element);
        var err = this.getLastError();

        if (err != 0) {
            console.log("LMSGetValue(" + element + ") failed with error code: " + err);
            return "";
        }

        return value;
    },

    // Set a value in the LMS
    setValue: function(element, value) {
        var api = this.getAPI();
        if (api == null) {
            console.log("Unable to locate the LMS's API Implementation. LMSSetValue was not successful.");
            return false;
        }

        var result = api.LMSSetValue(element, value);

        if (result.toString() != "true") {
            var err = this.getLastError();
            console.log("LMSSetValue(" + element + ", " + value + ") failed with error code: " + err);
            return false;
        }

        return true;
    },

    // Save data to the LMS
    commit: function() {
        var api = this.getAPI();
        if (api == null) {
            console.log("Unable to locate the LMS's API Implementation. LMSCommit was not successful.");
            return false;
        }

        var result = api.LMSCommit("");

        if (result.toString() != "true") {
            var err = this.getLastError();
            console.log("LMSCommit failed with error code: " + err);
            return false;
        }

        return true;
    },

    // Get the last error code
    getLastError: function() {
        var api = this.getAPI();
        if (api == null) {
            console.log("Unable to locate the LMS's API Implementation. LMSGetLastError was not successful.");
            return 0;
        }

        return api.LMSGetLastError();
    },

    // Get the error string
    getErrorString: function(errorCode) {
        var api = this.getAPI();
        if (api == null) {
            console.log("Unable to locate the LMS's API Implementation. LMSGetErrorString was not successful.");
            return "";
        }

        return api.LMSGetErrorString(errorCode);
    },

    // Get the diagnostic information
    getDiagnostic: function(errorCode) {
        var api = this.getAPI();
        if (api == null) {
            console.log("Unable to locate the LMS's API Implementation. LMSGetDiagnostic was not successful.");
            return "";
        }

        return api.LMSGetDiagnostic(errorCode);
    },

    // Set the lesson status
    setStatus: function(status) {
        return this.setValue("cmi.core.lesson_status", status);
    },

    // Get the lesson status
    getStatus: function() {
        return this.getValue("cmi.core.lesson_status");
    },

    // Set the score
    setScore: function(score, min, max) {
        this.setValue("cmi.core.score.raw", score);
        if (min != null) {
            this.setValue("cmi.core.score.min", min);
        }
        if (max != null) {
            this.setValue("cmi.core.score.max", max);
        }
        return true;
    },

    // Set completion status
    setCompleted: function() {
        return this.setStatus("completed");
    },

    // Set incomplete status
    setIncomplete: function() {
        return this.setStatus("incomplete");
    },

    // Set passed status
    setPassed: function() {
        return this.setStatus("passed");
    },

    // Set failed status
    setFailed: function() {
        return this.setStatus("failed");
    }
};

// Initialize SCORM when the page loads
window.addEventListener('load', function() {
    SCORM.initialize();

    // Set initial status to incomplete if not already set
    var status = SCORM.getStatus();
    if (status === "" || status === "not attempted") {
        SCORM.setIncomplete();
        SCORM.commit();
    }
});

// Terminate SCORM when the page unloads
window.addEventListener('beforeunload', function() {
    SCORM.setCompleted();
    SCORM.commit();
    SCORM.terminate();
});

// Also handle page hide for better mobile support
window.addEventListener('pagehide', function() {
    SCORM.setCompleted();
    SCORM.commit();
    SCORM.terminate();
});
