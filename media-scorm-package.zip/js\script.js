// Service Navigation
function openService(service) {
    // Add a smooth fade transition
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.3s ease';

    setTimeout(() => {
        if (service === 'spotify') {
            window.location.href = 'spotify.html#fullscreen';
        } else if (service === 'youtube') {
            window.location.href = 'youtube.html#fullscreen';
        }
    }, 300);
}

// Add keyboard navigation
document.addEventListener('keydown', (e) => {
    if (e.key === '1') {
        openService('spotify');
    } else if (e.key === '2') {
        openService('youtube');
    }
});

// Add entrance animation
window.addEventListener('load', () => {
    document.body.style.opacity = '1';
});

// Add touch/hover effects for mobile
document.querySelectorAll('.glass-card').forEach(card => {
    card.addEventListener('touchstart', function() {
        this.style.transform = 'translateY(-10px) scale(1.02)';
    });

    card.addEventListener('touchend', function() {
        this.style.transform = '';
    });
});

// Prevent default scroll behavior
document.addEventListener('touchmove', (e) => {
    if (e.target.closest('.glass-card') === null) {
        e.preventDefault();
    }
}, { passive: false });

// Add subtle mouse parallax effect
document.addEventListener('mousemove', (e) => {
    const cards = document.querySelectorAll('.glass-card');
    const mouseX = e.clientX / window.innerWidth;
    const mouseY = e.clientY / window.innerHeight;

    cards.forEach(card => {
        const rect = card.getBoundingClientRect();
        const cardCenterX = rect.left + rect.width / 2;
        const cardCenterY = rect.top + rect.height / 2;

        const deltaX = (e.clientX - cardCenterX) * 0.02;
        const deltaY = (e.clientY - cardCenterY) * 0.02;

        if (card.matches(':hover')) {
            card.style.transform = `translateY(-15px) scale(1.05) rotateY(${deltaX}deg) rotateX(${-deltaY}deg)`;
        }
    });
});
