// Service Navigation
function openService(service) {
    if (service === 'spotify') {
        window.location.href = 'spotify.html';
    } else if (service === 'youtube') {
        window.location.href = 'youtube.html';
    }
}

// Smooth Scroll to Section
function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// Scroll Reveal Animation
function revealOnScroll() {
    const reveals = document.querySelectorAll('.scroll-reveal');

    reveals.forEach(element => {
        const windowHeight = window.innerHeight;
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;

        if (elementTop < windowHeight - elementVisible) {
            element.classList.add('active');
        }
    });
}

// Counter Animation for Statistics
function animateCounter(element) {
    const target = parseInt(element.getAttribute('data-target'));
    const duration = 2000; // 2 seconds
    const increment = target / (duration / 16); // 60fps
    let current = 0;

    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 16);
}

// Animate Statistics When in View
function animateStatsOnScroll() {
    const statsSection = document.querySelector('.stats-section');
    if (!statsSection) return;

    const statNumbers = statsSection.querySelectorAll('.stat-number');
    const sectionTop = statsSection.getBoundingClientRect().top;
    const windowHeight = window.innerHeight;

    if (sectionTop < windowHeight - 200 && !statsSection.classList.contains('animated')) {
        statsSection.classList.add('animated');
        statNumbers.forEach(stat => {
            animateCounter(stat);
        });
    }
}

// Parallax Effect
function handleParallax() {
    const scrolled = window.pageYOffset;
    const parallaxElements = document.querySelectorAll('.gradient-orb');

    parallaxElements.forEach((element, index) => {
        const speed = 0.5 + (index * 0.2);
        const yPos = -(scrolled * speed);
        element.style.transform = `translateY(${yPos}px)`;
    });
}

// Mouse Move Effect on Hero
function handleMouseMove(e) {
    const hero = document.querySelector('.hero-content');
    if (!hero) return;

    const mouseX = e.clientX / window.innerWidth;
    const mouseY = e.clientY / window.innerHeight;

    const moveX = (mouseX - 0.5) * 30;
    const moveY = (mouseY - 0.5) * 30;

    hero.style.transform = `translate(${moveX}px, ${moveY}px)`;
}

// Add Hover Effect to Cards
function addCardHoverEffects() {
    const cards = document.querySelectorAll('.feature-card, .service-card, .gallery-item');

    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.zIndex = '10';
        });

        card.addEventListener('mouseleave', function() {
            this.style.zIndex = '1';
        });
    });
}

// Add Ripple Effect on Click
function createRipple(event) {
    const button = event.currentTarget;
    const ripple = document.createElement('span');
    const diameter = Math.max(button.clientWidth, button.clientHeight);
    const radius = diameter / 2;

    ripple.style.width = ripple.style.height = `${diameter}px`;
    ripple.style.left = `${event.clientX - button.offsetLeft - radius}px`;
    ripple.style.top = `${event.clientY - button.offsetTop - radius}px`;
    ripple.classList.add('ripple');

    const existingRipple = button.querySelector('.ripple');
    if (existingRipple) {
        existingRipple.remove();
    }

    button.appendChild(ripple);

    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// Add Ripple CSS
function injectRippleStyles() {
    if (document.querySelector('#ripple-styles')) return;

    const style = document.createElement('style');
    style.id = 'ripple-styles';
    style.textContent = `
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.6);
            transform: scale(0);
            animation: ripple-animation 0.6s ease-out;
            pointer-events: none;
        }

        @keyframes ripple-animation {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }

        button {
            position: relative;
            overflow: hidden;
        }
    `;
    document.head.appendChild(style);
}

// Add Keyboard Navigation
function handleKeyboardNavigation(e) {
    if (e.key === '1') {
        openService('spotify');
    } else if (e.key === '2') {
        openService('youtube');
    } else if (e.key === 'Escape') {
        scrollToSection('hero');
    }
}

// Lazy Load Images (for future image additions)
function lazyLoadImages() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                observer.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
}

// Add Smooth Fade In on Page Load
function fadeInOnLoad() {
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.5s ease';

    window.addEventListener('load', () => {
        document.body.style.opacity = '1';
    });
}

// Initialize Scroll Progress Indicator
function createScrollProgress() {
    const progressBar = document.createElement('div');
    progressBar.id = 'scroll-progress';
    progressBar.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 0%;
        height: 4px;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        z-index: 9999;
        transition: width 0.1s ease;
    `;
    document.body.appendChild(progressBar);
}

function updateScrollProgress() {
    const progressBar = document.getElementById('scroll-progress');
    if (!progressBar) return;

    const windowHeight = window.innerHeight;
    const documentHeight = document.documentElement.scrollHeight;
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

    const scrollPercent = (scrollTop / (documentHeight - windowHeight)) * 100;
    progressBar.style.width = scrollPercent + '%';
}

// Add Floating Action Button
function createFloatingButton() {
    const fab = document.createElement('button');
    fab.id = 'scroll-to-top';
    fab.innerHTML = '↑';
    fab.style.cssText = `
        position: fixed;
        bottom: 40px;
        right: 40px;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        font-size: 2rem;
        cursor: pointer;
        opacity: 0;
        transition: all 0.3s ease;
        z-index: 1000;
        box-shadow: 0 8px 24px rgba(102, 126, 234, 0.4);
    `;

    fab.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    document.body.appendChild(fab);
}

function toggleFloatingButton() {
    const fab = document.getElementById('scroll-to-top');
    if (!fab) return;

    if (window.pageYOffset > 500) {
        fab.style.opacity = '1';
        fab.style.transform = 'scale(1)';
    } else {
        fab.style.opacity = '0';
        fab.style.transform = 'scale(0.8)';
    }
}

// Prevent Context Menu (Optional - can be removed if needed)
function preventContextMenu() {
    document.addEventListener('contextmenu', (e) => {
        // Uncomment to disable right-click
        // e.preventDefault();
    });
}

// Initialize Everything
function initialize() {
    // Fade in on load
    fadeInOnLoad();

    // Inject ripple styles
    injectRippleStyles();

    // Create scroll progress bar
    createScrollProgress();

    // Create floating button
    createFloatingButton();

    // Add card hover effects
    addCardHoverEffects();

    // Add ripple to buttons
    const buttons = document.querySelectorAll('button, .service-card');
    buttons.forEach(button => {
        button.addEventListener('click', createRipple);
    });

    // Lazy load images
    lazyLoadImages();

    // Prevent context menu
    preventContextMenu();

    // Initial reveal check
    revealOnScroll();
    animateStatsOnScroll();
}

// Event Listeners
window.addEventListener('scroll', () => {
    revealOnScroll();
    animateStatsOnScroll();
    handleParallax();
    updateScrollProgress();
    toggleFloatingButton();
});

window.addEventListener('mousemove', handleMouseMove);
window.addEventListener('keydown', handleKeyboardNavigation);

// Run on DOM Content Loaded
document.addEventListener('DOMContentLoaded', initialize);

// Mark SCORM as completed
if (typeof SCORM !== 'undefined') {
    SCORM.setValue('cmi.core.lesson_location', 'main');
    SCORM.commit();
}

// Log for debugging
console.log('Media Experience Hub - Loaded Successfully');
